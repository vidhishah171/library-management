const mongoose = require('mongoose');

const leaderboardSchema = new mongoose.Schema({
  type: { type: String, required: true }, // 'Department' or 'Book'
  popularity: { type: String, required: true }, // 'Daily', 'Weekly', 'Monthly'
  entries: [{
    entityId: { type: String, required: true }, // departmentId or bookId
    name: { type: String, required: true }, // departmentName or bookTitle
    downloads: { type: Number, required: true },
    rank: { type: Number, required: true }
  }],
  lastWeekWinner: {
    id: { type: String, required: true }, // departmentId
    name: { type: String, required: true } // departmentName
  }
}, {
  timestamps: true
});

const Leaderboard = mongoose.model('Leaderboard', leaderboardSchema);

module.exports = Leaderboard;
