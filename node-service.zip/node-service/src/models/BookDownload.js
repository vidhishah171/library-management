const mongoose = require('mongoose');

const downloadSchema = new mongoose.Schema({
  bookId: { type: String, required: true },
  bookTitle: { type: String, required: true },
  departmentId: { type: String, required: true },
  departmentName: { type: String, required: true }
},
{
  timestamps: true
});

module.exports = mongoose.model('BookDownload', downloadSchema);
