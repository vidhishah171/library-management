const cron = require('node-cron');
const Book = require('../models/Book');
const Download = require('../models/BookDownload');

// Getting date ranges for fetching current and last week's data for least downloaded books.
const getDateRange = () => {
    const startOfThisWeek = new Date();
    const endOfThisWeek = new Date();
    startOfThisWeek.setDate(startOfThisWeek.getDate() - 7);
    const startOfLastWeek = new Date();
    const endOfLastWeek = new Date();
    endOfLastWeek.setDate(startOfThisWeek.getDate());
    startOfLastWeek.setDate(startOfThisWeek.getDate() - 7)
    return {startOfThisWeek, endOfThisWeek, startOfLastWeek, endOfLastWeek};
}

async function updateLeastDownloadedBooks() {
    try {
        console.log('Inside update Least Downloaded Books.')
        const { startOfThisWeek, endOfThisWeek, startOfLastWeek, endOfLastWeek } = getDateRange();

        // Aggregation pipeline to get least downloaded books
        const pipeline = (start, end) => [
            { $match: { createdAt: { $gte: start, $lt: end } } },
            { $group: { _id: '$bookId', downloads: { $sum: 1 }, bookTitle: { $first: '$bookTitle' } } },
            { $sort: { downloads: 1, _id: 1 } },
            { $limit: 1 } 
        ];

        const leastDownloadedBooksLastWeek = await Download.aggregate(pipeline(startOfLastWeek, endOfLastWeek));
        const leastDownloadedBooksThisWeek = await Download.aggregate(pipeline(startOfThisWeek, endOfThisWeek));

        if(leastDownloadedBooksThisWeek?.[0]) {
            console.log(`Least downloaded book for this week is: ${leastDownloadedBooksThisWeek[0].bookTitle} with Id: ${leastDownloadedBooksThisWeek[0]._id}`);
        }
        if(leastDownloadedBooksLastWeek?.[0]) {
            console.log(`Least downloaded book for previous week is: ${leastDownloadedBooksLastWeek[0].bookTitle} with Id: ${leastDownloadedBooksLastWeek[0]._id}`);
        }

          // Find books that are least downloaded for both weeks
        const booksToBeRemoved = leastDownloadedBooksLastWeek.filter(lastWeekBook => 
            leastDownloadedBooksThisWeek.some(thisWeekBook => thisWeekBook._id.toString() === lastWeekBook._id.toString())
        );
        if (booksToBeRemoved.length === 0) {
            console.log('No books to be removed this week.');
            return;
        }
        for (const bookData of booksToBeRemoved) {
            console.log(`Removing book: ${bookData.bookTitle} with Id: ${bookData._id}.`)
            await Book.findByIdAndDelete(bookData._id);
            await Download.deleteMany({ bookId: bookData._id }); // Remove download records for the book
            console.log(`Removed book: ${bookData.bookTitle} with Id: ${bookData._id} and its downloads.`);
}
    } catch (error) {
        console.error('Error removing least downloaded books:', error.message);
    }
}

// Scheduling this function to run at midnight every sunday
cron.schedule('0 0 * * 0', async () => {
    await updateLeastDownloadedBooks();
});