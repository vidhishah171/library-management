const express = require('express');
const Book = require('../models/Book');

const app = express();

app.use(express.json());

exports.getBooks = async (req, res) => {
    try {
      const books = await Book.find();
      res.status(200).json(books);
    } catch (err) {
      res.status(500).json({ error: `Unable to fetch books due to: ${err.message}.` });
    }
  };
