const express = require('express');
const Book = require('../models/Book');
const Department = require('../models/Department');
const Download = require('../models/BookDownload');

const app = express();
app.use(express.json());


exports.downloadBook = async (req, res) => {
  try {
    const { bookId } = req.params;

    // Fetch the book details
    const book = await Book.findById(bookId);
    if (!book) {
      return res.status(404).send(`Error: Book not found with Id: ${bookId}!`);
    }

    const { title, department } = book;

    // Fetch the department details
    const departmentObj = await Department.findOne({name: department });
    if (!departmentObj) {
      console.log('No department found with name: ' + book.department);
      return res.status(404).send('No department: ' + book.department +' found for the Book: ' + book.id);
    }

    const { id } = departmentObj;

    // Create a new download
    const newDownload = new Download({
      bookId,
      bookTitle: title,
      departmentId: id,
      departmentName: department
    });

    // Save the download to the database
    const savedDownload = await newDownload.save();

    console.log('Download recorded for the Book: '+ bookId);
    res.status(201).json(savedDownload);
  } catch (error) {
    console.log('Unable to download the book due to: ' + error.message);
    res.status(500).send('Unable to download the book due to: ' + error.message);
  }
};
