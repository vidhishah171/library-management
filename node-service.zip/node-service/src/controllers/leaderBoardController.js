const express = require('express');
const LeaderBoard = require('../models/LeaderBoard');


const app = express();

app.use(express.json());

exports.getLeaderBoard = async (req, res) => {
  try {
    const { type, popularity } = req.query;
    console.log(`Fetching ${popularity} popular ${type}.`)
    const leaderboard = await LeaderBoard.findOne({type, popularity }).sort({ updatedAt: -1 });
    
    if (!leaderboard) {
      return res.status(404).json({ error: `LeaderBoard not found for type: ${type} and popularity: ${popularity}.` });
    }
    console.log(`${leaderboard.entries?.length} Leaderboard entries found.`);
    res.status(200).send(leaderboard.entries);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: `Failed to fetch leaderboard data due to: ${error.message}.` });
  }
};
