const express = require('express');
const { downloadBook } = require('../controllers/downloadController');
const router = express.Router();

router.post('/:bookId', downloadBook);

module.exports = router;
