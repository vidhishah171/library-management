const express = require('express');
const { getLeaderBoard } = require('../controllers/leaderBoardController');
const router = express.Router();

router.get('/', getLeaderBoard);

module.exports = router;
