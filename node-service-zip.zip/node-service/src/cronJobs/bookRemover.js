const cron = require('node-cron');
const mongoose = require('mongoose');
const Download = require('../models/BookDownload');
const Book = require('../models/Book');

// Remove books logic
const removeLeastReadBooks = async () => {
  try {
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);

    // Find books that were least read/downloaded two weeks ago
    const leastReadBooks = await Download.aggregate([
      { $match: { downloadDate: { $lte: twoWeeksAgo } } },
      { $group: { _id: '$bookId', count: { $sum: 1 } } },
      { $sort: { count: 1 } }, // Sort ascending by count to get least read books first
      { $limit: 100 } // Adjust limit as per your database size and performance considerations
    ]);

    const leastReadBookIds = leastReadBooks.map(book => book._id);

    // Remove books from the Book collection
    await Book.deleteMany({ _id: { $in: leastReadBookIds } });

    console.log(`Removed ${leastReadBookIds.length} least read books.`);
  } catch (error) {
    console.error('Error removing least read books:', error);
  }
};

// Schedule book removal task weekly
cron.schedule('0 0 * * 0', () => removeLeastReadBooks()); // Every Sunday at midnight

