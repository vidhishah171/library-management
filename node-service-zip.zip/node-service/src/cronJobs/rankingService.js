const cron = require('node-cron');
const Download = require('../models/BookDownload');
const LeaderBoard = require('../models/LeaderBoard');

// Utility function to get start and end of a specific period
const getPeriodRange = (period) => {
  const now = new Date();
  let start, end;

  switch (period) {
    case 'Weekly':
        start = new Date(now);
        start.setDate(now.getDate() - 6);
        end = new Date(now);
        end.setDate(now.getDate());
        break;
      case 'Monthly':
        start = new Date(now);
        start.setMonth(now.getMonth() - 1);
        end = new Date(now);
        break;
      case 'Daily':
        start = new Date(now);
        start.setHours(0, 0, 0, 0);
        end = new Date(now);
        end.setHours(23, 59, 59, 999);
        break;
      default:
        start = new Date(0);
        end = new Date();
  }

  return { start, end };
};

// Function to update rankings
const updateRankings = async (type, period) => {
  try {
    const { start, end } = getPeriodRange(period);
    console.log('Updating rankings between ' + start + ' and end ' + end);

    console.log('Updating rankings for ' + period);
    const groupField = type === 'Department' ? '$departmentId' : '$bookId';
    const nameField = type === 'Department' ? '$departmentName' : '$bookTitle';

    const topEntries = await Download.aggregate([
      { $match: { createdAt: { $gte: start, $lte: end } } },
      { $group: { _id: { id: groupField, name: nameField }, count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]);

    if(period === 'Week' && type === 'Department') {
        
    }

    const leaderboardEntries = topEntries.map((entry, index) => ({
      entityId: entry._id.id,
      name: entry._id.name,
      count: entry.count,
      rank: index + 1
    }));

    // Store leaderboard data in the database
    await LeaderBoard.findOneAndUpdate(
      { type, period },
      { entries: leaderboardEntries },
      { upsert: true, new: true }
    );
  } catch (error) {
    console.error(error);
  }
};

// Schedule tasks
cron.schedule('0 * * * *', () => updateRankings('Book', 'Daily')); // Every hour
cron.schedule('0 0 * * 0', () => updateRankings('Book', 'Weekly')); // Every week
cron.schedule('0 0 1 * *', () => updateRankings('Book', 'Monthly')); // Every month
cron.schedule('0 0 * * *', () => updateRankings('Department', 'Weekly')); // Every day for weekly department rankings


// // Schedule tasks
// cron.schedule('* * * * *', () => updateRankings('Book', 'Daily')); // Every hour
// cron.schedule('* * * * *', () => updateRankings('Book', 'Weekly')); // Every week
// cron.schedule('* * * * *', () => updateRankings('Book', 'Monthly')); // Every month
// cron.schedule('* * * * *', () => updateRankings('Department', 'Weekly')); // Every day for weekly department rankings
