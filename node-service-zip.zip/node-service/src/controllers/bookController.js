const express = require('express');
const mongoose = require('mongoose');
const Book = require('../models/Book');
const Department = require('../models/Department');

const app = express();

app.use(express.json());

exports.getBooks = async (req, res) => {
    try {
      const books = await Book.find();
      res.status(200).json(books);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };

exports.downloadBook = async (req, res) => {
    try {
        const book = await Book.findById(req.params.id);
        if(!book) return res.status(404).send('Book not found');
        book.downloads += 1;
        book.dailyDownloads += 1;
        book.weeklyDownloads += 1;
        book.monthlyDownloads += 1;

        const department = await Department.findOne({name: book.department});
        if (department) {
            department.downloads += 1;
            await department.save();
        } else {
            console.log('No department found with name: ' + book.department);
            return res.status(404).send('No department: ' + book.department +' found for the Book: ' + book.id);
        }
        await book.save();
        res.status(200).send('Download recorded for the Book: '+ req.params.id);
    } catch(error) {
        console.log('Unable to download the book due to: ' + error.message);
        res.status(500).send('Unable to download the book due to: ' + error.message);
    }
};