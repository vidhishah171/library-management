const express = require('express');
const mongoose = require('mongoose');
const LeaderBoard = require('../models/LeaderBoard');


const app = express();

app.use(express.json());

exports.getLeaderBoard = async (req, res) => {
  try {
    const { type, period } = req.query;
    console.log(type,period)
    const leaderboard = await LeaderBoard.findOne({type, period }).sort({ updatedAt: -1 });
    console.log(leaderboard)
    if (!leaderboard) {
      return res.status(404).json({ error: 'LeaderBoard not found' });
    }
    console.log(leaderboard.entries)
    res.status(200).send(leaderboard.entries);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch leaderboard data' });
  }
};
