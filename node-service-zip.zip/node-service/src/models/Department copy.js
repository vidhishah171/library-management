const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  downloads: {type: Number, default: 0},
  weeklyDownloads: {type: Number, default: 0},
  rankDaily: {type: Number, default: 0},
  lastWeekWinner: Boolean
});

module.exports = mongoose.model('Department', departmentSchema);
