const mongoose = require('mongoose');

const leaderboardSchema = new mongoose.Schema({
  type: { type: String, required: true }, // 'department' or 'book'
  period: { type: String, required: true }, // 'day', 'week', 'month'
  entries: [{
    entityId: { type: String, required: true }, // departmentId or bookId
    name: { type: String, required: true }, // departmentName or bookTitle
    count: { type: Number, required: true },
    rank: { type: Number, required: true }
  }]
}, {
  timestamps: true
});

const Leaderboard = mongoose.model('Leaderboard', leaderboardSchema);

module.exports = Leaderboard;
