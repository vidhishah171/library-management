const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  department: { type: String, required: true },
  isbn: { type: String, required: true },
  genre: String,
  availibility: Boolean,
  publicationYear: Number,
  downloads: { type: Number, default: 0},
  dailyDownloads: { type: Number, default: 0},
  weeklyDownloads: { type: Number, default: 0},
  monthlyDownloads: { type: Number, default: 0},
  rankDaily: { type: Number, default: 0},
  rankWeekly: { type: Number, default: 0},
  rankMonthly: { type: Number, default: 0},
  leastReadWeeks: { type: Number, default: 0}
});

module.exports = mongoose.model('Book', bookSchema);
