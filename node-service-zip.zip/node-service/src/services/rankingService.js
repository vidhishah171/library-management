const Book = require('../models/Book');
const Department = require('../models/Department');
const cron = require('node-cron');

// Helper function to reset daily, weekly, and monthly downloads
async function resetDailyDownloads() {
    await Book.updateMany({}, { dailyDownloads: 0 });
}

async function resetWeeklyDownloads() {
    await Book.updateMany({}, { weeklyDownloads: 0 });
    const departments = await Department.find({}).sort({weeklyDownloads: -1}).limit(1);
    departments[0].lastWeekWinner = true;
    departments[0].save();
    await Department.updateMany({}, { weeklyDownloads: 0 });

}

async function resetMonthlyDownloads() {
    await Book.updateMany({}, { monthlyDownloads: 0 });
}


const updateRankings = async () => {
    const departments = await Department.find().sort({downloads: -1});
    departments.forEach((dept, index) => {
        dept.rankDaily = index + 1;
        dept.save();
    });

    const weeklyBooks = await Book.find().sort({downloadsWeekly: -1});
    weeklyBooks.forEach((book, index) => {
        book.rankWeekly = index + 1;
        book.save();
    });

    const monthlyBooks = await Book.find().sort({downloadsMonthly: -1});
    monthlyBooks.forEach((book, index) => {
        book.rankMonthly = index + 1;
        book.save();
    });

}

setInterval(updateRankings, 24*60*60*1000); // every day 24 hours


const updateTrendingBooks = async () => {
    const books = await Book.find().sort({downloadsDaily: -1}).limit(10);
    books.forEach((book, index) => {
        book.rankDaily = index + 1;
        book.save();
    });
}

setInterval(updateTrendingBooks, 60*60*1000); //every hour


const removeLeastReadBooks = async () => {
    const books = await Book.find().sort({downloads: 1}).limit(10);
    books.forEach((book, index) => {
        if(book.leastReadWeeks >= 2) {
            book.deleteOne();
        } else {
            book.leastReadWeeks++;
            book.save();
        }
    });
}

setInterval(removeLeastReadBooks, 7*24*60*60*1000);

// Scheduler to run the ranking updates
// Reset daily downloads at midnight
cron.schedule('0 0 * * *', async () => {
    await resetDailyDownloads();
});

// Reset weekly downloads at midnight on Sunday (first day of the week)
cron.schedule('0 0 * * 0', async () => {
    await resetWeeklyDownloads();
});

// Reset monthly downloads at midnight on the first day of the month
cron.schedule('0 0 1 * *', async () => {
    await resetMonthlyDownloads();
});