require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// const departmentRoutes = require('./routes/departmentRoutes');
const bookRoutes = require('./routes/bookRoutes');
const downloadRoutes = require('./routes/downloadRoutes');
const leaderBoardRoutes = require('./routes/leaderBoardRoutes');

const app = express();

// Middleware
app.use(bodyParser.json());

// Routes
// app.use('/departments', departmentRoutes);
app.use('/books', bookRoutes);
app.use('/download', downloadRoutes);
app.use('/leaderBoard', leaderBoardRoutes);

require('./cronJobs/rankingService');
require('./cronJobs/removeBookService');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('Failed to connect to MongoDB', err);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
