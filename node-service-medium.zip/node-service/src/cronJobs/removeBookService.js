const cron = require('node-cron');
const Book = require('../models/Book');
const Download = require('../models/BookDownload');
const { getPopularityRange } = require('./rankingService');

// async function updateLeastDownloadedBooks() {
//     try {
//         console.log('Inside update Least Downloaded Books.')
//         const leastDownloadedBooks = await Download.aggregate([
//             { $group: { _id: '$bookId', downloads: { $sum: 1 } } },
//             { $sort: { downloads: 1 } },
//             { $limit: 1 }
//         ]);

//         const today = new Date();

//         for (const bookData of leastDownloadedBooks) {
//             const book = await Book.findById(bookData._id);

//             if (book) {
//                 // Check if the book was in the least downloaded list yesterday
//                 if (book.lastLeastDownloadedDate && (today - book.lastLeastDownloadedDate) / (1000 * 60 * 60 * 24) <= 1) {
//                     book.leastDownloadedDays += 1;
//                 } else {
//                     book.leastDownloadedDays = 1;  // Reset to 1 since it's a new streak
//                 }

//                 book.lastLeastDownloadedDate = today;

//                 // If the book has been in the least downloaded list for 14 consecutive days, remove it
//                 if (book.leastDownloadedDays >= 14) {
//                     await Download.deleteMany({ bookId: book._id });
//                     await Book.findByIdAndDelete(book._id);
//                     console.log(`Removed book: ${book.title} and its downloads with Book Id: ${book._id})`);
//                 } else {
//                     await book.save();
//                 }
//             }
//         }
//     } catch (error) {
//         console.error('Error updating least downloaded books:', error.message);
//     }
// }

const getDateRange = () => {
    const startOfThisWeek = new Date();
    const endOfThisWeek = new Date();
    startOfThisWeek.setDate(startOfThisWeek.getDate() - 7);
    const startOfLastWeek = new Date();
    const endOfLastWeek = new Date();
    endOfLastWeek.setDate(startOfThisWeek.getDate());
    startOfLastWeek.setDate(startOfThisWeek.getDate() - 7)
    return {startOfThisWeek, endOfThisWeek, startOfLastWeek, endOfLastWeek};
}

async function updateLeastDownloadedBooks() {
    try {
        console.log('Inside update Least Downloaded Books.')
        const { startOfThisWeek, endOfThisWeek, startOfLastWeek, endOfLastWeek } = getDateRange();

        // Aggregation pipeline to get least downloaded books
        const pipeline = (start, end) => [
            { $match: { createdAt: { $gte: start, $lt: end } } },
            { $group: { _id: '$bookId', downloads: { $sum: 1 }, bookTitle: { $first: '$bookTitle' } } },
            { $sort: { downloads: 1, _id: 1 } },
            { $limit: 1 } 
        ];
        
        const leastDownloadedBooksLastWeek = await Download.aggregate(pipeline(startOfLastWeek, endOfLastWeek));
        const leastDownloadedBooksThisWeek = await Download.aggregate(pipeline(startOfThisWeek, endOfThisWeek));

        if(leastDownloadedBooksThisWeek?.[0]) {
            console.log(`Least downloaded book for this week is: ${leastDownloadedBooksThisWeek[0].bookTitle} with Id: ${leastDownloadedBooksThisWeek[0]._id}`);
        }
        if(leastDownloadedBooksLastWeek?.[0]) {
            console.log(`Least downloaded book for previous week is: ${leastDownloadedBooksLastWeek[0].bookTitle} with Id: ${leastDownloadedBooksLastWeek[0]._id}`);
        }

          // Find books that are least downloaded for both weeks
        const booksToBeRemoved = leastDownloadedBooksLastWeek.filter(lastWeekBook => 
            leastDownloadedBooksThisWeek.some(thisWeekBook => thisWeekBook._id.toString() === lastWeekBook._id.toString())
        );
        if (booksToBeRemoved.length === 0) {
            console.log('No books to be removed this week.');
            return;
        }
        for (const bookData of booksToBeRemoved) {
            console.log(`Removing book: ${bookData.bookTitle} with Id: ${bookData._id}.`)
            // await Book.findByIdAndDelete(bookData._id);
            // await Download.deleteMany({ bookId: bookData._id }); // Remove download records for the book
            console.log(`Removed book: ${bookData.bookTitle} with Id: ${bookData._id} and its downloads.`);
}
    } catch (error) {
        console.error('Error removing least downloaded books:', error.message);
    }
}






// Schedule this function to run at midnight every day
cron.schedule('* * * * *', async () => {
    await updateLeastDownloadedBooks();
});