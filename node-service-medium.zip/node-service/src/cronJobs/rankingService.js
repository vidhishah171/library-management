const cron = require('node-cron');
const Download = require('../models/BookDownload');
const LeaderBoard = require('../models/LeaderBoard');

// Utility function to get start and end of a specific period
const getPopularityRange = (popularity) => {
  const now = new Date();
  let start, end;

  switch (popularity) {
    case 'Weekly':
        start = new Date(now);
        start.setDate(now.getDate() - 7);
        end = new Date(now);
        end.setDate(now.getDate());
        break;
      case 'Monthly':
        start = new Date(now);
        start.setMonth(now.getMonth() - 1);
        end = new Date(now);
        break;
      case 'Daily':
        start = new Date(now);
        start.setHours(0, 0, 0, 0);
        end = new Date(now);
        end.setHours(23, 59, 59, 999);
        break;
      default:
        start = new Date(0);
        end = new Date();
  }

  return { start, end };
};

// Function to update rankings
const updateRankings = async (type, popularity) => {
  try {
    const { start, end } = getPopularityRange(popularity);
    console.log(`Updating ${popularity} ${type} rankings.`);
    const groupField = type === 'Department' ? '$departmentId' : '$bookId';
    const nameField = type === 'Department' ? '$departmentName' : '$bookTitle';

    const topEntries = await Download.aggregate([
      { $match: { createdAt: { $gte: start, $lte: end } } },
      { $group: { _id: { id: groupField, name: nameField }, downloads: { $sum: 1 } } },
      { $sort: { downloads: -1 } },
      { $limit: 10 }
    ]);

    let lastWeekWinner = null
    if(type === 'Department') {
        let { start, end } = getPopularityRange('Weekly');
        lastWeekWinner = await Download.aggregate([
          { $match: { createdAt: { $gte: start, $lte: end} } },
          { $group: { _id: { id: groupField, name: nameField }, downloads: { $sum: 1 } } },
          { $sort: { downloads: -1 } },
          { $limit: 1 }
        ]);
    }

    const leaderboardEntries = topEntries.map((entry, index) => ({
      entityId: entry._id.id,
      name: entry._id.name,
      downloads: entry.downloads,
      rank: index + 1
    }));

    // Store leaderboard data in the database
    await LeaderBoard.findOneAndUpdate(
      { type, popularity },
      { entries: leaderboardEntries, lastWeekWinner: lastWeekWinner?.[0]? lastWeekWinner[0]._id : ''},
      { upsert: true, new: true }
    );
    console.log(`Sucessfully updated ${popularity} ${type} rankings.`);
  } catch (error) {
    console.error(`Unable to update ${popularity} ${type} rankings due to: ${error.message}.`);
  }
};

// Schedule tasks
cron.schedule('0 * * * *', () => updateRankings('Book', 'Daily')); // Every hour
cron.schedule('0 0 * * 0', () => updateRankings('Book', 'Weekly')); // Every week
cron.schedule('0 0 1 * *', () => updateRankings('Book', 'Monthly')); // Every month
cron.schedule('0 0 * * *', () => updateRankings('Department', '')); // Every day for weekly department rankings


// Schedule tasks
cron.schedule('* * * * *', () => updateRankings('Book', 'Daily')); // Every hour
cron.schedule('* * * * *', () => updateRankings('Book', 'Weekly')); // Every week
cron.schedule('* * * * *', () => updateRankings('Book', 'Monthly')); // Every month
cron.schedule('* * * * *', () => updateRankings('Department', '')); // Every day for weekly department rankings


module.exports = { getPopularityRange };
