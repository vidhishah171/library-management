const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  department: { type: String, required: true },
  isbn: { type: String, required: true },
  genre: String,
  availibility: Boolean,
  publicationYear: Number
});

module.exports = mongoose.model('Book', bookSchema);
