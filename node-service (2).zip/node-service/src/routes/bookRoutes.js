const express = require('express');
const { addBook, getBooks, getTrendingBooks, downloadBook } = require('../controllers/bookController');
const router = express.Router();

router.get('/', getBooks);

module.exports = router;
